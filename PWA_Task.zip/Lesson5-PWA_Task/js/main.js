﻿window.addEventListener("DOMContentLoaded", function () {

})
